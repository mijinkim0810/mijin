package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.CareStudentVO;
import model.TeacherVO;

public class CareStudentDAO {
	public CareStudentVO getCareStudentregiste(CareStudentVO cvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into CareStudent  ");
		sql.append(
				"(c_no, c_name, c_gender, c_blood, c_rRN1, c_rRN2, c_medical, c_Address, c_Address2, c_Banname)");
		sql.append("values(CareStudent_SEQ.nextval,?,?,?,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		CareStudentVO cVo = cvo;

		try {
			con = DBUtil.getConnection();

			// scVo = new Student_ChildrenVO();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, cVo.getC_name());// �л��̸�
			pstmt.setString(2, cVo.getC_gender());// ����
			pstmt.setString(3, cVo.getC_blood());// ������
			pstmt.setInt(4, cVo.getC_rRN1());// �ֹι�ȣ 1
			pstmt.setInt(5, cVo.getC_rRN2());// �ֹι�ȣ 2
			pstmt.setString(6, cVo.getC_medical());// ��������
			pstmt.setString(7, cVo.getC_Address());// �ּ�
			pstmt.setString(8, cVo.getC_Address2());// ������ �ּ�
			pstmt.setString(9, cVo.getC_Banname());
			
			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("e_registe=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e_registe=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return cVo;
	}

	// ���̸��� �Է¹޾� ������ȸ ������
	public CareStudentVO getCareStudentCheck(String searchName) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudent where c_name like "); // name_info �ٲ����
		sql.append("? order by c_no desc");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentVO cVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(10, "%"+searchName+"%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				cVo = new CareStudentVO();
				cVo.setC_no(rs.getInt("c_no"));
				cVo.setC_name(rs.getString("c_name"));
				cVo.setC_gender(rs.getString("c_gender"));
				cVo.setC_blood(rs.getString("c_blood"));
				cVo.setC_rRN1(rs.getInt("c_rRN1"));
				cVo.setC_rRN2(rs.getInt("c_rRN2"));
				cVo.setC_medical(rs.getString("c_medical"));
				cVo.setC_Address(rs.getString("c_Address"));
				cVo.setC_Address2(rs.getString("c_Address2"));
				cVo.setC_Banname(rs.getString("c_Banname"));

			}
		} catch (SQLException se) {
			System.out.println("e_VOcheck=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_VOcheck=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return cVo;
	}

	// ������ �л��� ���� ����-�ʿ������

	// �л�����
	public void getCareStudentVODelete(int no_CareStudent) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete * from CareStudentVO where c_no=? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// dbutil�̶�� Ŭ������ getconnection() �޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// sql���� ������ ó�� ����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no_CareStudent);

			// sql���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л������Ϸ�");
				alert.setContentText("�л����� ����!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л�����");
				alert.setHeaderText("�л����� ����");
				alert.setContentText("�л����� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO: handle exception
			}
		}
	}

	// ���̺� ������
	public ArrayList<CareStudentVO> getCareStudentTotal() {
		ArrayList<CareStudentVO> list_C = new ArrayList<CareStudentVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudent order by c_no desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentVO cVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				cVo = new CareStudentVO();
			
				cVo.setC_no(rs.getInt("c_no"));
				cVo.setC_name(rs.getString("c_name"));
				cVo.setC_gender(rs.getString("c_gender"));
				cVo.setC_blood(rs.getString("c_blood"));
				cVo.setC_rRN1(rs.getInt("c_rRN1"));
				cVo.setC_rRN2(rs.getInt("c_rRN2"));
				cVo.setC_medical(rs.getString("c_medical"));
				cVo.setC_Address(rs.getString("c_Address"));
				cVo.setC_Address2(rs.getString("c_Address2"));
				cVo.setC_Banname(rs.getString("c_Banname"));
				list_C.add(cVo);
			}
		} catch (SQLException se) {
			System.out.println("e_Array=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_Array=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return list_C;
	}

	public CareStudentVO getCareStudentSearch(String name) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudent ");
		sql.append(" where c_name = ?");// name_info �ٲ����

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentVO cVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				cVo = new CareStudentVO();
				
				cVo.setC_name(rs.getString("c_name"));
				cVo.setC_gender(rs.getString("c_gender"));
				cVo.setC_blood(rs.getString("c_blood"));
				cVo.setC_rRN1(rs.getInt("c_rRN1"));
				cVo.setC_rRN2(rs.getInt("c_rRN2"));
				cVo.setC_medical(rs.getString("c_medical"));
				cVo.setC_Address(rs.getString("c_Address"));
				cVo.setC_Address2(rs.getString("c_Address2"));
				cVo.setC_Banname(rs.getString("c_Banname"));

			}
		} catch (SQLException se) {
			System.out.println("e_search=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_search=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				System.out.println(se);
			}
		}
		return cVo;

	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName_C() {
		ArrayList<String> columnName_C = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudent");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultSetMetaData��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName_C.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
			// TODO: handle exception
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return columnName_C;
	}
}