package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.CareStudentT_VO;
import model.CareStudentT_VO;
import model.TeacherVO;

public class CareStudentT_DAO {
	public CareStudentT_VO getCareStudentregiste(CareStudentT_VO ctvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into CareStudentT  ");
		sql.append(
				"(ct_no, ct_name, ct_gender, ct_blood, ct_rRN1, ct_rRN2, ct_medical, ct_Address, ct_Address2, ct_Banname)");
		sql.append("values(CareStudentT_SEQ.nextval,?,?,?,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		CareStudentT_VO ctVo = ctvo;

		try {
			con = DBUtil.getConnection();

			// sctVo = new Student_ChildrenVO();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, ctVo.getCt_name());// �л��̸�
			pstmt.setString(2, ctVo.getCt_gender());// ����
			pstmt.setString(3, ctVo.getCt_blood());// ������
			pstmt.setInt(4, ctVo.getCt_rRN1());// �ֹι�ȣ 1
			pstmt.setInt(5, ctVo.getCt_rRN2());// �ֹι�ȣ 2
			pstmt.setString(6, ctVo.getCt_medical());// ��������
			pstmt.setString(7, ctVo.getCt_Address());// �ּ�
			pstmt.setString(8, ctVo.getCt_Address2());// ������ �ּ�
			pstmt.setString(9, ctVo.getCt_Banname());
			
			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("e_registe=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e_registe=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return ctVo;
	}

	// ���̸��� �Է¹޾� ������ȸ ������
	public CareStudentT_VO getCareStudentTCheck(String searchName) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudent where ct_name like "); // name_info �ٲ����
		sql.append("? order by ct_no desc");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentT_VO ctVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(10, "%"+searchName+"%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				ctVo = new CareStudentT_VO();
				ctVo.setCt_no(rs.getInt("ct_no"));
				ctVo.setCt_name(rs.getString("ct_name"));
				ctVo.setCt_gender(rs.getString("ct_gender"));
				ctVo.setCt_blood(rs.getString("ct_blood"));
				ctVo.setCt_rRN1(rs.getInt("ct_rRN1"));
				ctVo.setCt_rRN2(rs.getInt("ct_rRN2"));
				ctVo.setCt_medical(rs.getString("ct_medical"));
				ctVo.setCt_Address(rs.getString("ct_Address"));
				ctVo.setCt_Address2(rs.getString("ct_Address2"));
				ctVo.setCt_Banname(rs.getString("ct_Banname"));

			}
		} catch (SQLException se) {
			System.out.println("e_VOcheck=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_VOcheck=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return ctVo;
	}

	// ������ �л��� ���� ����-�ʿ������

	// �л�����
	public void getCareStudentT_VODelete(int no_CareStudentT) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete * from CareStudentT_VO where ct_no=? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// dbutil�̶�� Ŭ������ getconnection() �޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// sql���� ������ ó�� ����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no_CareStudentT);

			// sql���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л������Ϸ�");
				alert.setContentText("�л����� ����!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л�����");
				alert.setHeaderText("�л����� ����");
				alert.setContentText("�л����� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO: handle exception
			}
		}
	}

	// ���̺� ������
	public ArrayList<CareStudentT_VO> getCareStudentTTotal() {
		ArrayList<CareStudentT_VO> list_Ct = new ArrayList<CareStudentT_VO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudentT order by ct_no desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentT_VO ctVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ctVo = new CareStudentT_VO();
			
				ctVo.setCt_no(rs.getInt("ct_no"));
				ctVo.setCt_name(rs.getString("ct_name"));
				ctVo.setCt_gender(rs.getString("ct_gender"));
				ctVo.setCt_blood(rs.getString("ct_blood"));
				ctVo.setCt_rRN1(rs.getInt("ct_rRN1"));
				ctVo.setCt_rRN2(rs.getInt("ct_rRN2"));
				ctVo.setCt_medical(rs.getString("ct_medical"));
				ctVo.setCt_Address(rs.getString("ct_Address"));
				ctVo.setCt_Address2(rs.getString("ct_Address2"));
				ctVo.setCt_Banname(rs.getString("ct_Banname"));
				list_Ct.add(ctVo);
			}
		} catch (SQLException se) {
			System.out.println("e_Array=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_Array=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return list_Ct;
	}

	public CareStudentT_VO getCareStudentSearch(String name) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudentT ");
		sql.append(" where ct_name = ?");// name_info �ٲ����

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CareStudentT_VO ctVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ctVo = new CareStudentT_VO();
				
				ctVo.setCt_name(rs.getString("ct_name"));
				ctVo.setCt_gender(rs.getString("ct_gender"));
				ctVo.setCt_blood(rs.getString("ct_blood"));
				ctVo.setCt_rRN1(rs.getInt("ct_rRN1"));
				ctVo.setCt_rRN2(rs.getInt("ct_rRN2"));
				ctVo.setCt_medical(rs.getString("ct_medical"));
				ctVo.setCt_Address(rs.getString("ct_Address"));
				ctVo.setCt_Address2(rs.getString("ct_Address2"));
				ctVo.setCt_Banname(rs.getString("ct_Banname"));

			}
		} catch (SQLException se) {
			System.out.println("e_search=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_search=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				System.out.println(se);
			}
		}
		return ctVo;

	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName_C() {
		ArrayList<String> columnName_Ct = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from CareStudentT");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultSetMetaData��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName_Ct.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
			// TODO: handle exception
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return columnName_Ct;
	}
}