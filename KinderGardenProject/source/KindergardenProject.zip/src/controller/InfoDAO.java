package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.InfoVO;
import model.KindergardenVO;

public class InfoDAO {
	// �Է�������
	public InfoVO getInforegiste(InfoVO ivo) throws Exception {
		String dml = "insert into info values (Info_Seq.nextval,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		InfoVO retval = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, ivo.getName_Info());
			pstmt.setString(2, ivo.getNumber_Info());
			pstmt.setString(3, ivo.getFloors_Info());

			int i = pstmt.executeUpdate();

			retval = new InfoVO();
		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	// ���̸��� �Է¹޾� ������ȸ ������
	public InfoVO getInfoCheck(String string) throws Exception {
		String dml = "select * from kindergarden where Name_Info =?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		InfoVO retval = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(4, "%" + string + "%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				retval = new InfoVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return retval;
	}

	// ���̺� ������
	public ArrayList<InfoVO> getInfoTotal() {
		ArrayList<InfoVO> list = new ArrayList<InfoVO>();
		String tml = "select * from info";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		InfoVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				emVo = new InfoVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
				System.out.println("emVo : " + emVo);
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return list;
	}

	//�ڵ��Է��� ���� ������
	public InfoVO getInfoSearch(String name) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from info ");
		sql.append(" where name_Info = ?");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		InfoVO iVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				iVo = new InfoVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				System.out.println(se);
			}
		}
		return iVo;

	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from Info";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultSetMetaData��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
			// TODO: handle exception
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return columnName;
	}
}
