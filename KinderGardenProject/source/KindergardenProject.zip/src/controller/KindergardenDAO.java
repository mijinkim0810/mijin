package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.KindergardenVO;

public class KindergardenDAO {
	//��� ������
public KindergardenVO getKindergardenregiste(KindergardenVO kvo) throws Exception{
	String dml ="insert into kindergarden values (kindergarden_Seq.nextval,?,?,?)";
	
	Connection con =null;
	PreparedStatement pstmt=null;
	KindergardenVO retval =null;
	try {
		con =DBUtil.getConnection();
		
		pstmt =con.prepareStatement(dml);
		pstmt.setString(1, kvo.getK_CLASS());
		pstmt.setInt(2, kvo.getK_PEOPLE());
		pstmt.setInt(3, kvo.getK_FLOORS());
		
		int i=pstmt.executeUpdate();
		
		retval =new KindergardenVO();
	}catch (SQLException e) {
		System.out.println("e=["+e+"]");
		
	}catch (Exception e) {
	System.out.println("e=["+e+"]");	
	
	}finally {
		try {
			if(pstmt !=null)
				pstmt.close();
			if(con != null)
				con.close();
			}catch (SQLException e) {
			}
	}
	return retval;
}

//���̸��� �Է¹޾� ������ȸ ������
public KindergardenVO getKindergardenCheck(String searchName) throws Exception{
	String dml ="select * from kindergarden where K_CLASS =?";
	
	Connection con =null;
	PreparedStatement pstmt =null;
	ResultSet rs =null;
	KindergardenVO retval =null;
	
	try {
		con =DBUtil.getConnection();
		pstmt =con.prepareStatement(dml);
		pstmt.setString(4, searchName);
		rs =pstmt.executeQuery();
		
		if(rs.next()) {
			retval =new KindergardenVO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4));
		}
	}catch(SQLException se) {
		System.out.println(se);
	}catch (Exception e) {
		System.out.println(e);
	}finally {
		try {
			if(rs!=null)
				rs.close();
			if(pstmt != null)
				pstmt.close();
			if(con != null)
				con.close();
		}catch(SQLException se) {
			
		}
	}
	return retval;
}

//���� ������
public void getKindergardenDelete(int no)throws Exception{
	//������ ó���� ���� sql��
	StringBuffer sql = new StringBuffer();
	sql.append("delete from kindergarden where k_no = ?");
	Connection con =null;
	PreparedStatement pstmt =null;
	
	try {
		//dbutil�̶�� Ŭ������ getConnection()�޼���� �����ͺ��̽��� ����
		con=DBUtil.getConnection();
		//sql���� ���� �� ó�� ����� ����
		pstmt =con.prepareStatement(sql.toString());
		pstmt.setInt(1, no);
		
		//sql���� ������ ó����� ����
		int i = pstmt.executeUpdate();
		
		if(i==1) {
			Alert alert =new Alert(AlertType.INFORMATION);
			alert.setTitle("�л�����");
			alert.setHeaderText("�л������Ϸ�");
			alert.setContentText("�л� ���� ����!");
			
			alert.showAndWait();
		}else {
			Alert alert =new Alert(AlertType.INFORMATION);
			alert.setTitle("�л�����");
			alert.setHeaderText("�л����� ����");
			alert.setContentText("�л� ���� ����!");
			
			alert.showAndWait();
		}
	}catch(SQLException e){
		System.out.println("e=["+e+"]");
		
	}catch (Exception e) {
		System.out.println("e=["+e+"]");
	}finally {
		try {
			if(pstmt != null)
				pstmt.close();
			if(con != null)
				con.close();
			
		}catch(SQLException e) {
			
		}
	}
}

//��Ż ������ - ���̺�
public ArrayList<KindergardenVO> getkindergardenTotal(){
	ArrayList<KindergardenVO> list =new ArrayList<KindergardenVO>();
	String tml ="select * from kindergarden";
	
	Connection con =null;
	PreparedStatement pstmt=null;
	ResultSet rs =null;
	KindergardenVO emVo =null;
	
	try {
		con=DBUtil.getConnection();
		pstmt=con.prepareStatement(tml);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			emVo = new KindergardenVO(rs.getInt(1),rs.getString(2), rs.getInt(3), rs.getInt(4));
			
			list.add(emVo);
		}
		}catch(SQLException se) {
			System.out.println(se);
		}catch (Exception e) {
			System.out.println(e);
		}finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(con != null)
					con.close();
			}catch (SQLException se) {
				// TODO: handle exception
			}
		}
			return list;
}

//�����ͺ��̽����� �л� ���̺��� �÷��� ����
public ArrayList<String> getColumnName(){
	ArrayList<String> columnName =new ArrayList<String>();
	
	String sql ="select * from kindergarden";
	Connection con = null;
	PreparedStatement pstmt =null;
	ResultSet rs =null;
	//resultSetMetaData��ü ���� ����
	ResultSetMetaData rsmd =null;
	try {
		con =DBUtil.getConnection();
		pstmt=con.prepareStatement(sql);
		rs=pstmt.executeQuery();
		rsmd=rs.getMetaData();
		int cols =rsmd.getColumnCount();
		for(int i=1;i<=cols;i++) {
			columnName.add(rsmd.getColumnName(i));
		}
	}catch (SQLException se) {
		System.out.println(se);
		// TODO: handle exception
	}catch (Exception e) {
		System.out.println(e);
		// TODO: handle exception
	}finally {
		try { 
			if(rs != null)
				rs.close();
			if(pstmt != null)
				pstmt.close();
			if(con != null)
				con.close();
		}catch (SQLException se) {
			// TODO: handle exception
		}
	}
	return columnName;
}
}
