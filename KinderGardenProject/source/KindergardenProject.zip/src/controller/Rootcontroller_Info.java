package controller;

import java.net.URL;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.InfoVO;

public class Rootcontroller_Info implements Initializable {
	// -----------------------------1��
	@FXML
	private Label lbfloor_R1;
	@FXML
	private Label lbname_R1_1;
	@FXML
	private Label lbpeopleNumber1_1;
	@FXML
	private Label lbname_R1_2;
	@FXML
	private Label lbpeopleNumber1_2;
	// -----------------------------2��
	@FXML
	private Label lbfloor_R2;
	@FXML
	private Label lbname_R2_1;
	@FXML
	private Label lbpeopleNumber2_1;
	@FXML
	private Label lbname_R2_2;
	@FXML
	private Label lbpeopleNumber2_2;

	// -----------------------------3��
	@FXML
	private Label lbfloor_R3;
	@FXML
	private Label lbname_R3_1;
	@FXML
	private Label lbpeopleNumber3_1;
	@FXML
	private Label lbname_R3_2;
	@FXML
	private Label lbpeopleNumber3_2;

	// -----------------------------4��
	@FXML
	private Label lbfloor_R4;
	@FXML
	private Label lbname_R4_1;
	@FXML
	private Label lbpeopleNumber4_1;
	@FXML
	private Label lbname_R4_2;
	@FXML
	private Label lbpeopleNumber4_2;

	// ------------------------------------

	@FXML // �ݰ��� ���̺�
	private TableView<InfoVO> tableView_Info = new TableView<>();

	ObservableList<InfoVO> data_Info = FXCollections.observableArrayList();
	ObservableList<InfoVO> data;

	InfoVO Inregistration = new InfoVO();

	int no;

	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		// ��ġ������â���� ���� ������ �� ��� ���� �������� ��Ʈ��

		TableColumn colno_Info = new TableColumn("��ȣ");
		colno_Info.setMaxWidth(200);
		colno_Info.setCellValueFactory(new PropertyValueFactory<>("no_Info"));

		TableColumn colname_Info = new TableColumn("���̸�");
		colname_Info.setMaxWidth(200);
		colname_Info.setCellValueFactory(new PropertyValueFactory<>("name_Info"));

		TableColumn colnumber_Info = new TableColumn("��");
		colnumber_Info.setMaxWidth(200);
		colnumber_Info.setCellValueFactory(new PropertyValueFactory<>("number_Info"));

		TableColumn colfloors_Info = new TableColumn("��");
		colfloors_Info.setMaxWidth(200);
		colfloors_Info.setCellValueFactory(new PropertyValueFactory<>("floors_Info"));

		tableView_Info.getColumns().addAll(colno_Info, colname_Info, colnumber_Info, colfloors_Info);

		totalList();

		tableView_Info.setItems(data_Info);

	}

	public void tableHandler(MouseEvent event) {
		data = tableView_Info.getSelectionModel().getSelectedItems();
		no = data.get(0).getNo_Info();

	}

	/*
	 * try { data_Info.removeAll(data_Info); InfoVO ivo = null;
	 * 
	 * InfoDAO idao = new InfoDAO();
	 * 
	 * ivo = new InfoVO(lbname_R1.getText(), lbfloor_R1_1.getText(),
	 * peopleNumber1_1.getText());
	 * 
	 * idao = new InfoDAO();
	 * 
	 * idao.getInforegiste(ivo); } catch (Exception e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); }
	 * 
	 * }
	 */

	public void totalList() {
		
			Object[][] totalData;

			InfoDAO iDao = new InfoDAO();
			InfoVO iVo = null;
			ArrayList<String> title;
			ArrayList<InfoVO> list;

			title = iDao.getColumnName();
			int columnCount = title.size();

			list = iDao.getInfoTotal();
			int rowCount = list.size();
			data_Info.add(iVo);

			totalData = new Object[rowCount][columnCount];

			for (int index = 0; index < rowCount; index++) {
				iVo = list.get(index);

				if (iVo.getFloors_Info().equals("1-1")) {
					lbfloor_R1.setText("1");
					lbname_R1_1.setText(iVo.getName_Info());
					lbpeopleNumber1_1.setText(iVo.getNumber_Info());
				}
				if (iVo.getFloors_Info().equals("1-2")) {

					lbname_R1_2.setText(iVo.getName_Info());
					lbpeopleNumber1_2.setText(iVo.getNumber_Info());
				}

				if (iVo.getFloors_Info().equals("2-1")) {
					lbfloor_R2.setText("2");
					lbname_R2_1.setText(iVo.getName_Info());
					lbpeopleNumber2_1.setText(iVo.getNumber_Info());

				}
				if (iVo.getFloors_Info().equals("2-2")) {
				
					lbname_R2_2.setText(iVo.getName_Info());
					lbpeopleNumber2_2.setText(iVo.getNumber_Info());

				}


				if (iVo.getFloors_Info().equals("3-1")) {
					lbfloor_R3.setText("3");
					lbname_R3_1.setText(iVo.getName_Info());
					lbpeopleNumber3_1.setText(iVo.getNumber_Info());

				}
				if (iVo.getFloors_Info().equals("3-2")) {

					lbname_R3_2.setText(iVo.getName_Info());
					lbpeopleNumber3_2.setText(iVo.getNumber_Info());

				}
				if (iVo.getFloors_Info().equals("4-1")) {
					lbfloor_R4.setText("4");
					lbname_R4_1.setText(iVo.getName_Info());
					lbpeopleNumber4_1.setText(iVo.getNumber_Info());

				}
				if (iVo.getFloors_Info().equals("4-2")) {
					
					lbname_R4_2.setText(iVo.getName_Info());
					lbpeopleNumber4_2.setText(iVo.getNumber_Info());

				}


				// sqldeveloper���� �� floor�ʿ� uniqe�־��ָ� �Ѱ��̻�ȵ� �����߸� ��� â�� �־���
			}

		
	}

}
