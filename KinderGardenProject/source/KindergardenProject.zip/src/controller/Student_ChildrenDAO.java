package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import model.Student_ChildrenVO;

public class Student_ChildrenDAO {

	public Student_ChildrenVO getStudent_Childrenregiste(Student_ChildrenVO scvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into Student_Children  ");
		sql.append(
				"(s_no, s_name, s_gender, s_blood, s_rRN1, s_rRN2, s_medical, s_Address, s_Address2, s_Banname, s_pName, s_pgender, s_pRRN1, s_pRRN2,s_pPhoneNumber,s_pJob, s_pworkingTime_Wd, s_pworkingTime_St, s_pworkingTime_Su, s_pay, s_brosis, s_nationalDiscount, s_discount, s_totalAC, s_payment_AC, filename_S, filename_P)");
		sql.append("values(STUDENT_CHILDREN_SEQ.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		Student_ChildrenVO scVo = scvo;

		try {
			con = DBUtil.getConnection();

			// scVo = new Student_ChildrenVO();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, scVo.getS_name());// �л��̸�
			pstmt.setString(2, scVo.getS_gender());// ����
			pstmt.setString(3, scVo.getS_blood());// ������
			pstmt.setInt(4, scVo.getS_rRN1());// �ֹι�ȣ 1
			pstmt.setInt(5, scVo.getS_rRN2());// �ֹι�ȣ 2
			pstmt.setString(6, scVo.getS_medical());// ��������
			pstmt.setString(7, scVo.getS_Address());// �ּ�
			pstmt.setString(8, scVo.getS_Address2());// ������ �ּ�
			pstmt.setString(9, scVo.getS_Banname());
			pstmt.setString(10, scVo.getS_pName());// �θ�� �̸�
			pstmt.setString(11, scVo.getS_pgender());// �θ�� ����
			pstmt.setInt(12, scVo.getS_pRRN1());// �θ�� �ֹι�ȣ1
			pstmt.setInt(13, scVo.getS_pRRN2());// �θ�� �ֹι�ȣ2
			pstmt.setString(14, scVo.getS_pPhoneNumber());// �θ�� ��ȭ��ȣ
			pstmt.setString(15, scVo.getS_pJob());// �θ�� ����
			pstmt.setString(16, scVo.getS_pworkingTime_Wd());// �ٹ��ð�-�޺��ڽ��� �ٲٱ�
			pstmt.setString(17, scVo.getS_pworkingTime_St());// �ٹ��ð�-�޺��ڽ��� �ٲٱ�
			pstmt.setString(18, scVo.getS_pworkingTime_Su());// �ٹ��ð�-�޺��ڽ��� �ٲٱ�
			pstmt.setString(19, scVo.getS_pay());// �⺻������
			pstmt.setString(20, scVo.getS_brosis());// �����ڸſ���
			pstmt.setString(21, scVo.getS_nationalDiscount()); // ������ ���� ����
			pstmt.setString(22, scVo.getS_discount());// ���ο���
			pstmt.setInt(23, scVo.getS_totalAC());// �Ѽ�����
			pstmt.setString(24, scVo.getS_payment_AC());// ���Կ���
			pstmt.setString(25, scVo.getFilename_S());// �����߰�
			pstmt.setString(26, scVo.getFilename_P());
			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("e_registe=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e_registe=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return scVo;
	}

	// ���̸��� �Է¹޾� ������ȸ ������
	public Student_ChildrenVO getStudent_ChildrenCheck(String searchName) throws Exception {
		String dml = "select * from Student_Children where s_name =?"; // name_info �ٲ����

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Student_ChildrenVO scVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(27, searchName);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				scVo = new Student_ChildrenVO();
				scVo.setS_no(rs.getInt("s_no"));
				scVo.setS_name(rs.getString("s_name"));
				scVo.setS_gender(rs.getString("s_gender"));
				scVo.setS_blood(rs.getString("s_blood"));
				scVo.setS_rRN1(rs.getInt("s_rRN1"));
				scVo.setS_rRN2(rs.getInt("s_rRN2"));
				scVo.setS_medical(rs.getString("s_medical"));
				scVo.setS_Address(rs.getString("s_Address"));
				scVo.setS_Address2(rs.getString("s_Address2"));
				scVo.setS_Banname(rs.getString("s_Banname"));
				scVo.setS_pName(rs.getString("s_pName"));
				scVo.setS_pgender(rs.getString("s_pgender"));
				scVo.setS_pRRN1(rs.getInt("s_pRRN1"));
				scVo.setS_pRRN2(rs.getInt("s_pRRN2"));
				scVo.setS_pPhoneNumber(rs.getString("s_pPhoneNumber"));
				scVo.setS_pJob(rs.getString("s_pJob"));
				scVo.setS_pworkingTime_Wd(rs.getString("s_pworkingTime_Wd"));
				scVo.setS_pworkingTime_St(rs.getString("s_pworkingTime_St"));
				scVo.setS_pworkingTime_Su(rs.getString("s_pworkingTime_Su"));
				scVo.setS_pay(rs.getString("s_pay"));
				scVo.setS_brosis(rs.getString("s_brosis"));
				scVo.setS_nationalDiscount(rs.getString("s_nationalDiscount"));
				scVo.setS_discount(rs.getString("s_discount"));
				scVo.setS_totalAC(rs.getInt("s_totalAC"));
				scVo.setS_payment_AC(rs.getString("s_payment_AC"));
				scVo.setFilename_S(rs.getString("filename_S"));
				scVo.setFilename_P(rs.getString("filename_P"));

			}
		} catch (SQLException se) {
			System.out.println("e_VOcheck=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_VOcheck=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return scVo;
	}

	// ������ �л��� ���� ����-�ʿ������

	// �л�����
	public void getStudentDelete(int no_student) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete * from Student_Children where s_no=? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// dbutil�̶�� Ŭ������ getconnection() �޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// sql���� ������ ó�� ����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no_student);

			// sql���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л������Ϸ�");
				alert.setContentText("�л����� ����!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л�����");
				alert.setHeaderText("�л����� ����");
				alert.setContentText("�л����� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO: handle exception
			}
		}
	}

	// ���̺� ������
	public ArrayList<Student_ChildrenVO> getStudent_ChildrenTotal() {
		ArrayList<Student_ChildrenVO> list_sc = new ArrayList<Student_ChildrenVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from student_children order by s_no desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Student_ChildrenVO scVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				scVo = new Student_ChildrenVO();
				scVo.setS_no(rs.getInt("s_no"));
				scVo.setS_name(rs.getString("s_name"));
				scVo.setS_gender(rs.getString("s_gender"));
				scVo.setS_blood(rs.getString("s_blood"));
				scVo.setS_rRN1(rs.getInt("s_rRN1"));
				scVo.setS_rRN2(rs.getInt("s_rRN2"));
				scVo.setS_medical(rs.getString("s_medical"));
				scVo.setS_Address(rs.getString("s_Address"));
				scVo.setS_Address2(rs.getString("s_Address2"));
				scVo.setS_Banname(rs.getString("s_Banname"));
				scVo.setS_pName(rs.getString("s_pName"));
				scVo.setS_pgender(rs.getString("s_pgender"));
				scVo.setS_pRRN1(rs.getInt("s_pRRN1"));
				scVo.setS_pRRN2(rs.getInt("s_pRRN2"));
				scVo.setS_pPhoneNumber(rs.getString("s_pPhoneNumber"));
				scVo.setS_pJob(rs.getString("s_pJob"));
				scVo.setS_pworkingTime_Wd(rs.getString("s_pworkingTime_Wd"));
				scVo.setS_pworkingTime_St(rs.getString("s_pworkingTime_St"));
				scVo.setS_pworkingTime_Su(rs.getString("s_pworkingTime_Su"));
				scVo.setS_pay(rs.getString("s_pay"));
				scVo.setS_brosis(rs.getString("s_brosis"));
				scVo.setS_nationalDiscount(rs.getString("s_nationalDiscount"));
				scVo.setS_discount(rs.getString("s_discount"));
				scVo.setS_totalAC(rs.getInt("s_totalAC"));
				scVo.setS_payment_AC(rs.getString("s_payment_AC"));
				scVo.setFilename_S(rs.getString("filename_S"));
				scVo.setFilename_P(rs.getString("filename_P"));

				list_sc.add(scVo);
			}
		} catch (SQLException se) {
			System.out.println("e_Array=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_Array=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return list_sc;
	}

	public Student_ChildrenVO getStudent_ChildrenSearch(String name) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Student_Children ");
		sql.append(" where s_name = ?");// name_info �ٲ����

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Student_ChildrenVO scVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				scVo = new Student_ChildrenVO();
				scVo.setS_name(rs.getString("s_name"));
				scVo.setS_gender(rs.getString("s_gender"));
				scVo.setS_blood(rs.getString("s_blood"));
				scVo.setS_rRN1(rs.getInt("s_rRN1"));
				scVo.setS_rRN2(rs.getInt("s_rRN2"));
				scVo.setS_medical(rs.getString("s_medical"));
				scVo.setS_Address(rs.getString("s_Address"));
				scVo.setS_Address2(rs.getString("s_Address2"));
				scVo.setS_Banname(rs.getString("s_Banname"));
				scVo.setS_pName(rs.getString("s_pName"));
				scVo.setS_pgender(rs.getString("s_pgender"));
				scVo.setS_pRRN1(rs.getInt("s_pRRN1"));
				scVo.setS_pRRN2(rs.getInt("s_pRRN2"));
				scVo.setS_pPhoneNumber(rs.getString("s_pPhoneNumber"));
				scVo.setS_pJob(rs.getString("s_pJob"));
				scVo.setS_pworkingTime_Wd(rs.getString("s_pworkingTime_Wd"));
				scVo.setS_pworkingTime_St(rs.getString("s_pworkingTime_St"));
				scVo.setS_pworkingTime_Su(rs.getString("s_pworkingTime_Su"));
				scVo.setS_pay(rs.getString("s_pay"));
				scVo.setS_brosis(rs.getString("s_brosis"));
				scVo.setS_nationalDiscount(rs.getString("s_nationalDiscount"));
				scVo.setS_discount(rs.getString("s_discount"));
				scVo.setS_totalAC(rs.getInt("s_totalAC"));
				scVo.setS_payment_AC(rs.getString("s_payment_AC"));
				scVo.setFilename_S(rs.getString("filename_S"));
				scVo.setFilename_P(rs.getString("filename_P"));

			}
		} catch (SQLException se) {
			System.out.println("e_search=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_search=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				System.out.println(se);
			}
		}
		return scVo;

	}
	
	

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from student_children");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultSetMetaData��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
			// TODO: handle exception
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return columnName;
	}
}
