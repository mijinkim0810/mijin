package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import model.TeacherVO;

public class TeacherDAO {

	public TeacherVO getStudent_Childrenregiste(TeacherVO tvo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into Teacher  ");
		sql.append(
				"(t_no, t_name, t_gender, t_rank, t_prenumber, t_bankname, t_accountnumber, t_rrn, t_rrn2, t_high, t_college, t_banname, t_cretification, t_enterdate, t_phone, t_filename)");
		sql.append("values(Teacher_SEQ.nextval,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		TeacherVO tVo = tvo;

		try {
			con = DBUtil.getConnection();

			// scVo = new Student_ChildrenVO();

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, tVo.getT_name());// �̸�
			pstmt.setString(2, tVo.getT_gender());// ����
			pstmt.setString(3, tVo.getT_rank());// ����
			pstmt.setInt(4, tVo.getT_prenumber());// ���
			pstmt.setString(5, tVo.getT_bankname());// �����
			pstmt.setString(6, tVo.getT_accountnumber());// ���¹�ȣ
			pstmt.setInt(7, tVo.getT_rrn());// �ֹι�ȣ
			pstmt.setString(8, tVo.getT_rrn2());//�ֹι�ȣ
			pstmt.setString(9, tVo.getT_high());// �����б�
			pstmt.setString(10, tVo.getT_college());// ���б�
			pstmt.setString(11, tVo.getT_banname());
			pstmt.setString(12, tVo.getT_cretification());// �ڰ��� 
			pstmt.setString(13, tVo.getT_phone());// ��ȭ��ȣ
			pstmt.setString(14, tVo.getT_filename());// �̹���--15
			
			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("e_registe=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e_registe=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return tVo;
	}

	// ���̸��� �Է¹޾� ������ȸ ������
	public TeacherVO getStudent_ChildrenCheck(String searchName) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Teacher where t_name like "); // name_info �ٲ����
		sql.append("? order by t_no desc");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TeacherVO tVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(26, "%"+searchName+"%");
			rs = pstmt.executeQuery();

			if (rs.next()) {
				tVo = new TeacherVO();
				tVo.setT_no(rs.getInt("t_no"));
				tVo.setT_name(rs.getString("t_name"));
				tVo.setT_gender(rs.getString("t_gender"));
				tVo.setT_rank(rs.getString("t_rank"));
				tVo.setT_prenumber(rs.getInt("t_prenumber"));
				tVo.setT_bankname(rs.getString("t_bankname"));
				tVo.setT_accountnumber(rs.getString("t_accountnumber"));
				tVo.setT_rrn(rs.getInt("t_rrn"));
				tVo.setT_rrn2(rs.getString("t_rrn2"));
				tVo.setT_high(rs.getString("t_high"));
				tVo.setT_college(rs.getString("t_College"));
				tVo.setT_banname(rs.getString("t_banname"));
				tVo.setT_cretification(rs.getString("t_cretification"));
				tVo.setT_enterdate(rs.getString("t_enterdate"));
				tVo.setT_phone(rs.getString("t_phone"));
				tVo.setT_filename(rs.getString("t_filename"));
				

			}
		} catch (SQLException se) {
			System.out.println("e_VOcheck=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_VOcheck=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return tVo;
	}

	// ������ �л��� ���� ����-�ʿ������

	// �л�����
	public void getTeacherDelete(int no_teacher) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete * from Teacher where t_no=? ");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// dbutil�̶�� Ŭ������ getconnection() �޼���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// sql���� ������ ó�� ����� ����
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no_teacher);

			// sql���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л� ����");
				alert.setHeaderText("�л������Ϸ�");
				alert.setContentText("�л����� ����!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�л�����");
				alert.setHeaderText("�л����� ����");
				alert.setContentText("�л����� ����");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO: handle exception
			}
		}
	}

	// ���̺� ������
	public ArrayList<TeacherVO> getTeacherTotal() {
		ArrayList<TeacherVO> list_t = new ArrayList<TeacherVO>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from teacher order by t_no desc");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TeacherVO tVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				tVo = new TeacherVO();
			
				tVo.setT_no(rs.getInt("t_no"));
				tVo.setT_name(rs.getString("t_name"));
				tVo.setT_gender(rs.getString("t_gender"));
				tVo.setT_rank(rs.getString("t_rank"));
				tVo.setT_prenumber(rs.getInt("t_prenumber"));
				tVo.setT_bankname(rs.getString("t_bankname"));
				tVo.setT_accountnumber(rs.getString("t_accountnumber"));
				tVo.setT_rrn(rs.getInt("t_rrn"));
				tVo.setT_rrn2(rs.getString("t_rrn2"));
				tVo.setT_high(rs.getString("t_high"));
				tVo.setT_college(rs.getString("t_College"));
				tVo.setT_banname(rs.getString("t_banname"));
				tVo.setT_cretification(rs.getString("t_cretification"));
				tVo.setT_enterdate(rs.getString("t_enterdate"));
				tVo.setT_phone(rs.getString("t_phone"));
				tVo.setT_filename(rs.getString("t_filename"));
				list_t.add(tVo);
			}
		} catch (SQLException se) {
			System.out.println("e_Array=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_Array=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return list_t;
	}

	public TeacherVO getTeacherSearch(String name) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from Teacher ");
		sql.append(" where t_name = ?");// name_info �ٲ����

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TeacherVO tVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				tVo = new TeacherVO();
				
				tVo.setT_name(rs.getString("t_name"));
				tVo.setT_gender(rs.getString("t_gender"));
				tVo.setT_rank(rs.getString("t_rank"));
				tVo.setT_prenumber(rs.getInt("t_prenumber"));
				tVo.setT_bankname(rs.getString("t_bankname"));
				tVo.setT_accountnumber(rs.getString("t_accountnumber"));
				tVo.setT_rrn(rs.getInt("t_rrn"));
				tVo.setT_rrn2(rs.getString("t_rrn2"));
				tVo.setT_high(rs.getString("t_high"));
				tVo.setT_college(rs.getString("t_College"));
				tVo.setT_banname(rs.getString("t_banname"));
				tVo.setT_cretification(rs.getString("t_cretification"));
				tVo.setT_enterdate(rs.getString("t_enterdate"));
				tVo.setT_phone(rs.getString("t_phone"));
				tVo.setT_filename(rs.getString("t_filename"));

			}
		} catch (SQLException se) {
			System.out.println("e_search=[" + se + "]");
		} catch (Exception e) {
			System.out.println("e_search=[" + e + "]");
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				System.out.println(se);
			}
		}
		return tVo;

	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName_T() {
		ArrayList<String> columnName_T = new ArrayList<String>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from teacher");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// resultSetMetaData��ü ���� ����
		ResultSetMetaData rsmd = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName_T.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
			// TODO: handle exception
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				// TODO: handle exception
			}
		}
		return columnName_T;
	}
}
