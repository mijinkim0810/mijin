package model;

import javafx.scene.control.Label;

//������̺� ������ getter-setter
public class CareStudentT_VO {
	
	private int ct_no;
	private String ct_name; //�л��̸�---1
	private String ct_gender; //����---2
	private String ct_blood; //������---3
	private int ct_rRN1; //�ֹι�ȣ 1---4
	private int ct_rRN2; //�ֹι�ȣ 2---5
	private String ct_medical; //��������---6
	private String ct_Address; //�ּ�---7
	private String ct_Address2; //������ �ּ�---8
	private String ct_Banname;//���̸�--9
	
	public CareStudentT_VO() {
		super();
	}

	public CareStudentT_VO(String ct_name, String ct_gender, String ct_blood, int ct_rRN1, int ct_rRN2, String ct_medical,
			String ct_Address, String ct_Address2, String ct_Banname) {
		super();
		this.ct_name = ct_name;
		this.ct_gender = ct_gender;
		this.ct_blood = ct_blood;
		this.ct_rRN1 = ct_rRN1;
		this.ct_rRN2 = ct_rRN2;
		this.ct_medical = ct_medical;
		this.ct_Address = ct_Address;
		this.ct_Address2 = ct_Address2;
		this.ct_Banname = ct_Banname;
	}

	public CareStudentT_VO(int ct_no, String ct_name, String ct_gender, String ct_blood, int ct_rRN1, int ct_rRN2,
			String ct_medical, String ct_Address, String ct_Address2, String ct_Banname) {
		super();
		this.ct_no = ct_no;
		this.ct_name = ct_name;
		this.ct_gender = ct_gender;
		this.ct_blood = ct_blood;
		this.ct_rRN1 = ct_rRN1;
		this.ct_rRN2 = ct_rRN2;
		this.ct_medical = ct_medical;
		this.ct_Address = ct_Address;
		this.ct_Address2 = ct_Address2;
		this.ct_Banname = ct_Banname;
	}

	public int getCt_no() {
		return ct_no;
	}

	public void setCt_no(int ct_no) {
		this.ct_no = ct_no;
	}

	public String getCt_name() {
		return ct_name;
	}

	public void setCt_name(String ct_name) {
		this.ct_name = ct_name;
	}

	public String getCt_gender() {
		return ct_gender;
	}

	public void setCt_gender(String ct_gender) {
		this.ct_gender = ct_gender;
	}

	public String getCt_blood() {
		return ct_blood;
	}

	public void setCt_blood(String ct_blood) {
		this.ct_blood = ct_blood;
	}

	public int getCt_rRN1() {
		return ct_rRN1;
	}

	public void setCt_rRN1(int ct_rRN1) {
		this.ct_rRN1 = ct_rRN1;
	}

	public int getCt_rRN2() {
		return ct_rRN2;
	}

	public void setCt_rRN2(int ct_rRN2) {
		this.ct_rRN2 = ct_rRN2;
	}

	public String getCt_medical() {
		return ct_medical;
	}

	public void setCt_medical(String ct_medical) {
		this.ct_medical = ct_medical;
	}

	public String getCt_Address() {
		return ct_Address;
	}

	public void setCt_Address(String ct_Address) {
		this.ct_Address = ct_Address;
	}

	public String getCt_Address2() {
		return ct_Address2;
	}

	public void setCt_Address2(String ct_Address2) {
		this.ct_Address2 = ct_Address2;
	}

	public String getCt_Banname() {
		return ct_Banname;
	}

	public void setCt_Banname(String ct_Banname) {
		this.ct_Banname = ct_Banname;
	}
	
	
	
	
	
	
}
