package model;

import javafx.scene.control.Label;

//������̺� ������ getter-setter
public class CareStudentVO {
	
	private int c_no;
	private String c_name; //�л��̸�---1
	private String c_gender; //����---2
	private String c_blood; //������---3
	private int c_rRN1; //�ֹι�ȣ 1---4
	private int c_rRN2; //�ֹι�ȣ 2---5
	private String c_medical; //��������---6
	private String c_Address; //�ּ�---7
	private String c_Address2; //������ �ּ�---8
	private String c_Banname;//���̸�--9
	
	public CareStudentVO() {
		super();
	}

	public CareStudentVO(String c_name, String c_gender, String c_blood, int c_rRN1, int c_rRN2, String c_medical,
			String c_Address, String c_Address2, String c_Banname) {
		super();
		this.c_name = c_name;
		this.c_gender = c_gender;
		this.c_blood = c_blood;
		this.c_rRN1 = c_rRN1;
		this.c_rRN2 = c_rRN2;
		this.c_medical = c_medical;
		this.c_Address = c_Address;
		this.c_Address2 = c_Address2;
		this.c_Banname = c_Banname;
	}

	public CareStudentVO(int c_no, String c_name, String c_gender, String c_blood, int c_rRN1, int c_rRN2,
			String c_medical, String c_Address, String c_Address2, String c_Banname) {
		super();
		this.c_no = c_no;
		this.c_name = c_name;
		this.c_gender = c_gender;
		this.c_blood = c_blood;
		this.c_rRN1 = c_rRN1;
		this.c_rRN2 = c_rRN2;
		this.c_medical = c_medical;
		this.c_Address = c_Address;
		this.c_Address2 = c_Address2;
		this.c_Banname = c_Banname;
	}

	public int getC_no() {
		return c_no;
	}

	public void setC_no(int c_no) {
		this.c_no = c_no;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_gender() {
		return c_gender;
	}

	public void setC_gender(String c_gender) {
		this.c_gender = c_gender;
	}

	public String getC_blood() {
		return c_blood;
	}

	public void setC_blood(String c_blood) {
		this.c_blood = c_blood;
	}

	public int getC_rRN1() {
		return c_rRN1;
	}

	public void setC_rRN1(int c_rRN1) {
		this.c_rRN1 = c_rRN1;
	}

	public int getC_rRN2() {
		return c_rRN2;
	}

	public void setC_rRN2(int c_rRN2) {
		this.c_rRN2 = c_rRN2;
	}

	public String getC_medical() {
		return c_medical;
	}

	public void setC_medical(String c_medical) {
		this.c_medical = c_medical;
	}

	public String getC_Address() {
		return c_Address;
	}

	public void setC_Address(String c_Address) {
		this.c_Address = c_Address;
	}

	public String getC_Address2() {
		return c_Address2;
	}

	public void setC_Address2(String c_Address2) {
		this.c_Address2 = c_Address2;
	}

	public String getC_Banname() {
		return c_Banname;
	}

	public void setC_Banname(String c_Banname) {
		this.c_Banname = c_Banname;
	}
	
	
	
	
	
	
}
