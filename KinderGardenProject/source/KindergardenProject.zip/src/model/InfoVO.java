package model;

public class InfoVO {
	//��ġ�����â���� ������ ���� a�� �ִ� ����
	private int no_Info;
	public String name_Info;
	public String number_Info;
	public String floors_Info;

	public InfoVO() {
		super();
	}

	
	
	public InfoVO(String name_Info, String number_Info) {
		super();
		this.name_Info = name_Info;
		this.number_Info = number_Info;
	}



	public InfoVO(String name_Info, String number_Info, String floors_Info) {
		super();
		this.name_Info = name_Info;
		this.number_Info = number_Info;
		this.floors_Info = floors_Info;
	}

	public InfoVO(int no_Info, String name_Info, String number_Info, String floors_Info) {
		super();
		this.no_Info = no_Info;
		this.name_Info = name_Info;
		this.number_Info = number_Info;
		this.floors_Info = floors_Info;
	}


	public int getNo_Info() {
		return no_Info;
	}


	public void setNo_Info(int no_Info) {
		this.no_Info = no_Info;
	}


	public String getName_Info() {
		return name_Info;
	}


	public void setName_Info(String name_Info) {
		this.name_Info = name_Info;
	}


	public String getNumber_Info() {
		return number_Info;
	}


	public void setNumber_Info(String number_Info) {
		this.number_Info = number_Info;
	}


	public String getFloors_Info() {
		return floors_Info;
	}


	public void setFloors_Info(String floors_Info) {
		this.floors_Info = floors_Info;
	}


	@Override
	public String toString() {
		return "InfoVO [getNo_Info()=" + getNo_Info() + ", getName_Info()=" + getName_Info() + ", getNumber_Info()="
				+ getNumber_Info() + ", getFloors_Info()=" + getFloors_Info() + "]";
	}
	
	
	
		
}
