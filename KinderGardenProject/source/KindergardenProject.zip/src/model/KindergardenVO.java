package model;

public class KindergardenVO {
	private int K_NO;
	private String K_CLASS;
	private int K_PEOPLE;
	private int K_FLOORS;
	public KindergardenVO() {
		super();
	}
	public KindergardenVO(String k_CLASS, int k_PEOPLE, int k_FLOORS) {
		super();
		K_CLASS = k_CLASS;
		K_PEOPLE = k_PEOPLE;
		K_FLOORS = k_FLOORS;
	}
	public KindergardenVO(int k_NO, String k_CLASS, int k_PEOPLE, int k_FLOORS) {
		super();
		K_NO = k_NO;
		K_CLASS = k_CLASS;
		K_PEOPLE = k_PEOPLE;
		K_FLOORS = k_FLOORS;
	}
	public int getK_NO() {
		return K_NO;
	}
	public void setK_NO(int k_NO) {
		K_NO = k_NO;
	}
	public String getK_CLASS() {
		return K_CLASS;
	}
	public void setK_CLASS(String k_CLASS) {
		K_CLASS = k_CLASS;
	}
	public int getK_PEOPLE() {
		return K_PEOPLE;
	}
	public void setK_PEOPLE(int k_PEOPLE) {
		K_PEOPLE = k_PEOPLE;
	}
	public int getK_FLOORS() {
		return K_FLOORS;
	}
	public void setK_FLOORS(int k_FLOORS) {
		K_FLOORS = k_FLOORS;
	}
	
	

	
}
