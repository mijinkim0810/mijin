package model;

public class Student_ChildrenVO {
private int s_no;
private String s_name; //�л��̸�---1
private String s_gender; //����---2
private String s_blood; //������---3
private int s_rRN1; //�ֹι�ȣ 1---4
private int s_rRN2; //�ֹι�ȣ 2---5
private String s_medical; //��������---6
private String s_Address; //�ּ�---7
private String s_Address2; //������ �ּ�---8
private String s_Banname;//���̸�--9
//------------��ȣ��
private String s_pName; //�θ�� �̸�---10
private String s_pgender; //�θ�� ����---11
private int s_pRRN1; //�θ�� �ֹι�ȣ1---12
private int s_pRRN2; //�θ�� �ֹι�ȣ2---13
private String s_pPhoneNumber; //�θ�� ��ȭ��ȣ---14
private String s_pJob; //�θ�� ����---15
private String s_pworkingTime_Wd;//�ٹ��ð�-�޺��ڽ��� �ٲٱ�---16
private String s_pworkingTime_St;//�ٹ� ��--17
private String s_pworkingTime_Su;//�ٹ� ��--18
//------------������ ����
private String s_pay; //�⺻������---19
private String s_brosis; //�����ڸſ���---20
private String s_nationalDiscount; //������ ���� ����---21
private String s_discount; //���ο���---22
private int s_totalAC; //�Ѽ�����---23
private String s_payment_AC;//���Կ���---24

private String filename_S=null;//���� �߰�---25
private String filename_P=null;//�кθ��߰�---26

public Student_ChildrenVO() {
	super();
}

public Student_ChildrenVO(String s_name, String s_gender, String s_blood, int s_rRN1, int s_rRN2, String s_medical,
		String s_Address, String s_Address2, String s_Banname, String s_pName, String s_pgender, int s_pRRN1, int s_pRRN2,
		String s_pPhoneNumber, String s_pJob, String s_pworkingTime_Wd, String s_pworkingTime_St,
		String s_pworkingTime_Su, String s_pay, String s_brosis, String s_nationalDiscount, String s_discount,
		String string, int s_totalAC, String s_payment_AC, String filename_S, String filename_P) {
	super();
	this.s_name = s_name;
	this.s_gender = s_gender;
	this.s_blood = s_blood;
	this.s_rRN1 = s_rRN1;
	this.s_rRN2 = s_rRN2;
	this.s_medical = s_medical;
	this.s_Address = s_Address;
	this.s_Address2 = s_Address2;
	this.s_Banname =s_Banname;
	this.s_pName = s_pName;
	this.s_pgender = s_pgender;
	this.s_pRRN1 = s_pRRN1;
	this.s_pRRN2 = s_pRRN2;
	this.s_pPhoneNumber = s_pPhoneNumber;
	this.s_pJob = s_pJob;
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
	this.s_pworkingTime_St = s_pworkingTime_St;
	this.s_pworkingTime_Su = s_pworkingTime_Su;
	this.s_pay = s_pay;
	this.s_brosis = s_brosis;
	this.s_nationalDiscount = s_nationalDiscount;
	this.s_discount = s_discount;
	this.s_totalAC = s_totalAC;
	this.s_payment_AC = s_payment_AC;
	this.filename_S = filename_S;
	this.filename_P = filename_P;
}




public Student_ChildrenVO(int s_no, String s_name, String s_gender, String s_blood, int s_rRN1, int s_rRN2,
		String s_medical, String s_Address, String s_Address2, String s_Banname, String s_pName, String s_pgender, int s_pRRN1,
		int s_pRRN2, String s_pPhoneNumber, String s_pJob, String s_pworkingTime_Wd, String s_pworkingTime_St,
		String s_pworkingTime_Su, String s_pay, String s_brosis, String s_nationalDiscount, String s_discount,
		int s_totalAC, String s_payment_AC) {
	super();
	this.s_no = s_no;
	this.s_name = s_name;
	this.s_gender = s_gender;
	this.s_blood = s_blood;
	this.s_rRN1 = s_rRN1;
	this.s_rRN2 = s_rRN2;
	this.s_medical = s_medical;
	this.s_Address = s_Address;
	this.s_Address2 = s_Address2;
	this.s_Banname =s_Banname;
	this.s_pName = s_pName;
	this.s_pgender = s_pgender;
	this.s_pRRN1 = s_pRRN1;
	this.s_pRRN2 = s_pRRN2;
	this.s_pPhoneNumber = s_pPhoneNumber;
	this.s_pJob = s_pJob;
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
	this.s_pworkingTime_St = s_pworkingTime_St;
	this.s_pworkingTime_Su = s_pworkingTime_Su;
	this.s_pay = s_pay;
	this.s_brosis = s_brosis;
	this.s_nationalDiscount = s_nationalDiscount;
	this.s_discount = s_discount;
	this.s_totalAC = s_totalAC;
	this.s_payment_AC = s_payment_AC;
}

public Student_ChildrenVO(String s_name, String s_gender, String s_blood, int s_rRN1, int s_rRN2, String s_medical,
		String s_Address, String s_Address2, String s_Banname, String s_pName, String s_pgender, int s_pRRN1, int s_pRRN2,
		String s_pPhoneNumber, String s_pJob, String s_pworkingTime_Wd, String s_pworkingTime_St,
		String s_pworkingTime_Su, String s_pay, String s_brosis, String s_nationalDiscount, String s_discount,
		int s_totalAC, String s_payment_AC) {
	super();
	this.s_name = s_name;
	this.s_gender = s_gender;
	this.s_blood = s_blood;
	this.s_rRN1 = s_rRN1;
	this.s_rRN2 = s_rRN2;
	this.s_medical = s_medical;
	this.s_Address = s_Address;
	this.s_Address2 = s_Address2;
	this.s_Banname =s_Banname;
	this.s_pName = s_pName;
	this.s_pgender = s_pgender;
	this.s_pRRN1 = s_pRRN1;
	this.s_pRRN2 = s_pRRN2;
	this.s_pPhoneNumber = s_pPhoneNumber;
	this.s_pJob = s_pJob;
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
	this.s_pworkingTime_St = s_pworkingTime_St;
	this.s_pworkingTime_Su = s_pworkingTime_Su;
	this.s_pay = s_pay;
	this.s_brosis = s_brosis;
	this.s_nationalDiscount = s_nationalDiscount;
	this.s_discount = s_discount;
	this.s_totalAC = s_totalAC;
	this.s_payment_AC = s_payment_AC;
}

public Student_ChildrenVO(int s_no, String s_name, String s_gender, String s_blood, int s_rRN1, int s_rRN2,
		String s_medical, String s_Address, String s_Address2, String s_Banname, String s_pName, String s_pgender, int s_pRRN1,
		int s_pRRN2, String s_pPhoneNumber, String s_pJob, String s_pworkingTime_Wd, String s_pworkingTime_St,
		String s_pworkingTime_Su, String s_pay, String s_brosis, String s_nationalDiscount, String s_discount,
		int s_totalAC, String s_payment_AC, String filename_S, String filename_P) {
	super();
	this.s_no = s_no;
	this.s_name = s_name;
	this.s_gender = s_gender;
	this.s_blood = s_blood;
	this.s_rRN1 = s_rRN1;
	this.s_rRN2 = s_rRN2;
	this.s_medical = s_medical;
	this.s_Address = s_Address;
	this.s_Address2 = s_Address2;
	this.s_Banname =s_Banname;
	this.s_pName = s_pName;
	this.s_pgender = s_pgender;
	this.s_pRRN1 = s_pRRN1;
	this.s_pRRN2 = s_pRRN2;
	this.s_pPhoneNumber = s_pPhoneNumber;
	this.s_pJob = s_pJob;
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
	this.s_pworkingTime_St = s_pworkingTime_St;
	this.s_pworkingTime_Su = s_pworkingTime_Su;
	this.s_pay = s_pay;
	this.s_brosis = s_brosis;
	this.s_nationalDiscount = s_nationalDiscount;
	this.s_discount = s_discount;
	this.s_totalAC = s_totalAC;
	this.s_payment_AC = s_payment_AC;
	this.filename_S = filename_S;
	this.filename_P = filename_P;
}

public Student_ChildrenVO(int s_rRN1, int s_rRN2, int s_pRRN1, int s_pRRN2, String s_payment_AC) {
	super();
	this.s_rRN1 = s_rRN1;
	this.s_rRN2 = s_rRN2;
	this.s_pRRN1 = s_pRRN1;
	this.s_pRRN2 = s_pRRN2;
	this.s_payment_AC = s_payment_AC;
}

public Student_ChildrenVO(int s_no, String s_name, String s_gender, String s_blood, String s_medical, String s_Address,
		String s_Address2, String s_Banname, String s_pName, String s_pgender, String s_pPhoneNumber, String s_pJob,
		String s_pworkingTime_Wd, String s_pworkingTime_St, String s_pworkingTime_Su, String s_pay, String s_brosis,
		String s_nationalDiscount, String s_discount, int s_totalAC, String filename_S, String filename_P) {
	super();
	this.s_no = s_no;
	this.s_name = s_name;
	this.s_gender = s_gender;
	this.s_blood = s_blood;
	this.s_medical = s_medical;
	this.s_Address = s_Address;
	this.s_Address2 = s_Address2;
	this.s_Banname =s_Banname;
	this.s_pName = s_pName;
	this.s_pgender = s_pgender;
	this.s_pPhoneNumber = s_pPhoneNumber;
	this.s_pJob = s_pJob;
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
	this.s_pworkingTime_St = s_pworkingTime_St;
	this.s_pworkingTime_Su = s_pworkingTime_Su;
	this.s_pay = s_pay;
	this.s_brosis = s_brosis;
	this.s_nationalDiscount = s_nationalDiscount;
	this.s_discount = s_discount;
	this.s_totalAC = s_totalAC;
	this.filename_S = filename_S;
	this.filename_P = filename_P;
}

public int getS_no() {
	return s_no;
}

public void setS_no(int s_no) {
	this.s_no = s_no;
}

public String getS_name() {
	return s_name;
}

public void setS_name(String s_name) {
	this.s_name = s_name;
}

public String getS_gender() {
	return s_gender;
}

public void setS_gender(String s_gender) {
	this.s_gender = s_gender;
}

public String getS_blood() {
	return s_blood;
}

public void setS_blood(String s_blood) {
	this.s_blood = s_blood;
}

public int getS_rRN1() {
	return s_rRN1;
}

public void setS_rRN1(int s_rRN1) {
	this.s_rRN1 = s_rRN1;
}

public int getS_rRN2() {
	return s_rRN2;
}

public void setS_rRN2(int s_rRN2) {
	this.s_rRN2 = s_rRN2;
}

public String getS_medical() {
	return s_medical;
}

public void setS_medical(String s_medical) {
	this.s_medical = s_medical;
}

public String getS_Address() {
	return s_Address;
}

public void setS_Address(String s_Address) {
	this.s_Address = s_Address;
}

public String getS_Address2() {
	return s_Address2;
}

public void setS_Address2(String s_Address2) {
	this.s_Address2 = s_Address2;
}

public String getS_Banname() {
	return s_Banname;
}

public void setS_Banname(String s_Banname) {
	this.s_Banname = s_Banname;
}

public String getS_pName() {
	return s_pName;
}

public void setS_pName(String s_pName) {
	this.s_pName = s_pName;
}

public String getS_pgender() {
	return s_pgender;
}

public void setS_pgender(String s_pgender) {
	this.s_pgender = s_pgender;
}

public int getS_pRRN1() {
	return s_pRRN1;
}

public void setS_pRRN1(int s_pRRN1) {
	this.s_pRRN1 = s_pRRN1;
}

public int getS_pRRN2() {
	return s_pRRN2;
}

public void setS_pRRN2(int s_pRRN2) {
	this.s_pRRN2 = s_pRRN2;
}

public String getS_pPhoneNumber() {
	return s_pPhoneNumber;
}

public void setS_pPhoneNumber(String s_pPhoneNumber) {
	this.s_pPhoneNumber = s_pPhoneNumber;
}

public String getS_pJob() {
	return s_pJob;
}

public void setS_pJob(String s_pJob) {
	this.s_pJob = s_pJob;
}

public String getS_pworkingTime_Wd() {
	return s_pworkingTime_Wd;
}

public void setS_pworkingTime_Wd(String s_pworkingTime_Wd) {
	this.s_pworkingTime_Wd = s_pworkingTime_Wd;
}

public String getS_pworkingTime_St() {
	return s_pworkingTime_St;
}

public void setS_pworkingTime_St(String s_pworkingTime_St) {
	this.s_pworkingTime_St = s_pworkingTime_St;
}

public String getS_pworkingTime_Su() {
	return s_pworkingTime_Su;
}

public void setS_pworkingTime_Su(String s_pworkingTime_Su) {
	this.s_pworkingTime_Su = s_pworkingTime_Su;
}

public String getS_pay() {
	return s_pay;
}

public void setS_pay(String s_pay) {
	this.s_pay = s_pay;
}

public String getS_brosis() {
	return s_brosis;
}

public void setS_brosis(String s_brosis) {
	this.s_brosis = s_brosis;
}

public String getS_nationalDiscount() {
	return s_nationalDiscount;
}

public void setS_nationalDiscount(String s_nationalDiscount) {
	this.s_nationalDiscount = s_nationalDiscount;
}

public String getS_discount() {
	return s_discount;
}

public void setS_discount(String s_discount) {
	this.s_discount = s_discount;
}

public int getS_totalAC() {
	return s_totalAC;
}

public void setS_totalAC(int s_totalAC) {
	this.s_totalAC = s_totalAC;
}

public String getS_payment_AC() {
	return s_payment_AC;
}

public void setS_payment_AC(String s_payment_AC) {
	this.s_payment_AC = s_payment_AC;
}

public String getFilename_S() {
	return filename_S;
}

public void setFilename_S(String filename_S) {
	this.filename_S = filename_S;
}

public String getFilename_P() {
	return filename_P;
}

public void setFilename_P(String filename_P) {
	this.filename_P = filename_P;
}







}
