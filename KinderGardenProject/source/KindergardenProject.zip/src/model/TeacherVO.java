package model;

public class TeacherVO {
private int t_no; //������ ��ȣ
private String t_name; //������ �̸�----2
private String t_gender;//������ ����--3
private String t_rank;//������ ����--4
private int t_prenumber;//�����Ի��--5
private String t_bankname;//������ �����--6
private String t_accountnumber;//������ ���¹�ȣ--7
private int t_rrn;//������ �ֹι�ȣ--8
private String t_rrn2;//�������ֹι�ȣ--9
private String t_high;//������ �����б�--10
private String t_college;//������ ���б�--11
private String t_banname;//�����̸�--12
private String t_cretification;//�������ڰ���--13
private String t_enterdate;//�������Ի�����--14
private String t_phone;//������ ��ȭ��ȣ--15
private String t_filename=null;//�������̹����߰�---16

public TeacherVO() {
	super();
}

public TeacherVO(String t_name, String t_gender, String t_rank, int t_prenumber, String t_bankname,
		String t_accountnumber, int t_rrn, String t_rrn2, String t_high, String t_college, String t_banname,
		String t_cretification, String t_enterdate, String t_phone, String t_filename) {
	super();
	this.t_name = t_name;
	this.t_gender = t_gender;
	this.t_rank = t_rank;
	this.t_prenumber = t_prenumber;
	this.t_bankname = t_bankname;
	this.t_accountnumber = t_accountnumber;
	this.t_rrn = t_rrn;
	this.t_rrn2 = t_rrn2;
	this.t_high = t_high;
	this.t_college = t_college;
	this.t_banname = t_banname;
	this.t_cretification = t_cretification;
	this.t_enterdate = t_enterdate;
	this.t_phone = t_phone;
	this.t_filename = t_filename;
}

public TeacherVO(int t_no, String t_name, String t_gender, String t_rank, int t_prenumber, String t_bankname,
		String t_accountnumber, int t_rrn, String t_rrn2, String t_high, String t_college, String t_banname,
		String t_cretification, String t_enterdate, String t_phone) {
	super();
	this.t_no = t_no;
	this.t_name = t_name;
	this.t_gender = t_gender;
	this.t_rank = t_rank;
	this.t_prenumber = t_prenumber;
	this.t_bankname = t_bankname;
	this.t_accountnumber = t_accountnumber;
	this.t_rrn = t_rrn;
	this.t_rrn2 = t_rrn2;
	this.t_high = t_high;
	this.t_college = t_college;
	this.t_banname = t_banname;
	this.t_cretification = t_cretification;
	this.t_enterdate = t_enterdate;
	this.t_phone = t_phone;
}

public TeacherVO(String t_name, String t_gender, String t_rank, int t_prenumber, String t_bankname,
		String t_accountnumber, int t_rrn, String t_rrn2, String t_high, String t_college, String t_banname,
		String t_cretification, String t_enterdate, String t_phone) {
	super();
	this.t_name = t_name;
	this.t_gender = t_gender;
	this.t_rank = t_rank;
	this.t_prenumber = t_prenumber;
	this.t_bankname = t_bankname;
	this.t_accountnumber = t_accountnumber;
	this.t_rrn = t_rrn;
	this.t_rrn2 = t_rrn2;
	this.t_high = t_high;
	this.t_college = t_college;
	this.t_banname = t_banname;
	this.t_cretification = t_cretification;
	this.t_enterdate = t_enterdate;
	this.t_phone = t_phone;
}

public TeacherVO(String t_name, String t_gender, String t_rank, int t_prenumber, String t_bankname,
		String t_accountnumber, int t_rrn, String t_rrn2, String t_high, String t_college, String t_banname,
		String t_cretification, String t_phone) {
	super();
	this.t_name = t_name;
	this.t_gender = t_gender;
	this.t_rank = t_rank;
	this.t_prenumber = t_prenumber;
	this.t_bankname = t_bankname;
	this.t_accountnumber = t_accountnumber;
	this.t_rrn = t_rrn;
	this.t_rrn2 = t_rrn2;
	this.t_high = t_high;
	this.t_college = t_college;
	this.t_banname = t_banname;
	this.t_cretification = t_cretification;
	this.t_phone = t_phone;
}

public TeacherVO(int t_no, String t_name, String t_gender, String t_rank, int t_prenumber, String t_bankname,
		String t_accountnumber, int t_rrn, String t_rrn2, String t_high, String t_college, String t_cretification,
		String t_enterdate, String t_phone) {
	super();
	this.t_no = t_no;
	this.t_name = t_name;
	this.t_gender = t_gender;
	this.t_rank = t_rank;
	this.t_prenumber = t_prenumber;
	this.t_bankname = t_bankname;
	this.t_accountnumber = t_accountnumber;
	this.t_rrn = t_rrn;
	this.t_rrn2 = t_rrn2;
	this.t_high = t_high;
	this.t_college = t_college;
	this.t_cretification = t_cretification;
	this.t_enterdate = t_enterdate;
	this.t_phone = t_phone;
}

public int getT_no() {
	return t_no;
}

public void setT_no(int t_no) {
	this.t_no = t_no;
}

public String getT_name() {
	return t_name;
}

public void setT_name(String t_name) {
	this.t_name = t_name;
}

public String getT_gender() {
	return t_gender;
}

public void setT_gender(String t_gender) {
	this.t_gender = t_gender;
}

public String getT_rank() {
	return t_rank;
}

public void setT_rank(String t_rank) {
	this.t_rank = t_rank;
}

public int getT_prenumber() {
	return t_prenumber;
}

public void setT_prenumber(int t_prenumber) {
	this.t_prenumber = t_prenumber;
}

public String getT_bankname() {
	return t_bankname;
}

public void setT_bankname(String t_bankname) {
	this.t_bankname = t_bankname;
}

public String getT_accountnumber() {
	return t_accountnumber;
}

public void setT_accountnumber(String t_accountnumber) {
	this.t_accountnumber = t_accountnumber;
}

public int getT_rrn() {
	return t_rrn;
}

public void setT_rrn(int t_rrn) {
	this.t_rrn = t_rrn;
}

public String getT_rrn2() {
	return t_rrn2;
}

public void setT_rrn2(String t_rrn2) {
	this.t_rrn2 = t_rrn2;
}

public String getT_high() {
	return t_high;
}

public void setT_high(String t_high) {
	this.t_high = t_high;
}

public String getT_college() {
	return t_college;
}

public void setT_college(String t_college) {
	this.t_college = t_college;
}

public String getT_banname() {
	return t_banname;
}

public void setT_banname(String t_banname) {
	this.t_banname = t_banname;
}

public String getT_cretification() {
	return t_cretification;
}

public void setT_cretification(String t_cretification) {
	this.t_cretification = t_cretification;
}

public String getT_enterdate() {
	return t_enterdate;
}

public void setT_enterdate(String t_enterdate) {
	this.t_enterdate = t_enterdate;
}

public String getT_phone() {
	return t_phone;
}

public void setT_phone(String t_phone) {
	this.t_phone = t_phone;
}

public String getT_filename() {
	return t_filename;
}

public void setT_filename(String t_filename) {
	this.t_filename = t_filename;
}





}
